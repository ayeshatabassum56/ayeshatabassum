#pragma once
#include"Book.h";
#include"Student.h";
#include"Issuebook.h";
#include"ReturnBook.h";
#include<conio.h>
#include<Windows.h>
class LibraryManagementSystem
{
private:
	book c;
	Student s;
	Issuebook u;
public:
	void page();
	void login();
	void firstmenu();
};

