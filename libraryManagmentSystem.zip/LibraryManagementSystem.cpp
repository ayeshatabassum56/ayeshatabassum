#include "LibraryManagementSystem.h"
void LibraryManagementSystem::page()
{
	system("COLOR 87");
	cout << endl << endl;
	cout << "\t\t\t\t*************************************************\n";
	cout << "\t\t\t\t|                                               |\n";
	cout << "\t\t\t\t|                 Welcome  to   our             |\n";
	cout << "\t\t\t\t|                                               |\n";
	cout << "\t\t\t\t|             LIBARARY MANEGMENT SYSTEM         |\n";
	cout << "\t\t\t\t|                                               |\n";
	cout << "\t\t\t\t|-----------------------------------------------|\n";
	cout << "\t\t\t\t| In this System You can do following functions |\n";
	cout << "\t\t\t\t|-----------------------------------------------|\n";
	cout << "\t\t\t\t|         ;-) create a book record              |\n";
	cout << "\t\t\t\t|          ;-) Modify a book record             |\n";
	cout << "\t\t\t\t|          ;-) Search a book record             |\n";
	cout << "\t\t\t\t|          ;-) Delete a book record             |\n";
	cout << "\t\t\t\t|         ;-) Add a student record              |\n";
	cout << "\t\t\t\t|      ;-) Modify in a student record           |\n";
	cout << "\t\t\t\t|        ;-) Search a student record            |\n";
	cout << "\t\t\t\t|        ;-) Delete a student record            |\n";
	cout << "\t\t\t\t|  ;-) check validity of book & student record  |\n";
	cout << "\t\t\t\t|        ;-) issue a book to a student          |\n";
	cout << "\t\t\t\t|        ;-) Return book to librarian           |\n";
	cout << "\t\t\t\t|         ;-) Add a student record              |\n";
	cout << "\t\t\t\t*************************************************\n";

}
void LibraryManagementSystem::firstmenu()
{
	system("cls");
	page();
	system("pause");
	system("cls");
	system("COLOR 7C");
	int ch;
	do
	{
		system("cls");
		cout << "\t\t\t\t*************************************************\n";
		cout << "\t\t\t\t|                                               |\n";
		cout << "\t\t\t\t|             LIBARARY MANEGMENT SYSTEM         |\n";
		cout << "\t\t\t\t|                                               |\n";
		cout << "\t\t\t\t*************************************************\n";
		cout << "\n\t\t\t\t **M E N U**";
		cout << "\n\n\n\t 1.BOOK MANAGEMENT SYSTEM SECTION";
		cout << "\n\n\n\t 2.Student MANAGEMENT SYSTEM SECTION";
		cout << "\n\n\n\t 3.CHECK VALIDITY OF BOOKS AND STUDENTS";  
		cout << "\n\n\n\t 4.Issue and Return Status";
		cout << "\n\n\n\t 0.EXIT";
		cout << "\n\n\n\t  Enter Your Choice In Which Section You Want To Go::";
		cin >> ch;
		switch (ch)
		{
		case 1:
			c.print();
			break;
		case 2:
			s.show();
			break;
		case 3:
			u.validity();
			break;
		case 4:
			c.showissueandreturn();
		case 0:
			break;
		default:
			cout << "\nInvalid choice";
		}
		cout << endl;
		system("Pause");
		system("cls");
	} while (ch != 0);
}
void LibraryManagementSystem::login()
{
	system("COLOR 7C");
	cout << endl << endl;
	cout << "\t\t\t\t*************************************************\n";
	cout << "\t\t\t\t|                                               |\n";
	cout << "\t\t\t\t|             LIBARARY MANEGMENT SYSTEM         |\n";
	cout << "\t\t\t\t|                                               |\n";
	cout << "\t\t\t\t*************************************************\n";
	cout << endl << endl;
	char ch1 = 'y';
	int i, j, k;
	char uid[10], ch, pass2[10], tuid[13] = "0450", tpass[10] = "ayesha";
	while (ch1 == 'y')
	{
		cout << "\n\n\n\t\t\tEnter Userid::";
		cin >> uid;
		cout << "\n\t\t\tEnter Passcode(6 Characters)::";
		for (i = 0; i < 6; i++)
		{
			pass2[i] = _getch();
			cout << "*";
		}
		pass2[i] = '\0';
		if (!strcmp(pass2, tpass) && !strcmp(uid, tuid))
		{
			cout << "\n\n\t\t You have been succesfully logged in......";
			_getch();
			break;
		}
		else
		{
			cout << "\n\n\t\t Password entered is incorrect........";
			_getch();
		}
		cout << "\n\n\t\t Do you want to try again (y/n).....??";
		cin >> ch1;
	}
}