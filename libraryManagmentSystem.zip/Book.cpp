#include "Book.h"
void book::create()
{
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << "\t\t\t| LIBARARY MANEGMENT SYSTEM |" << endl;
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << endl;
	string bid, nop, bn, an, in;
	cout << "Enter the attributes of book which you want to create in the library!" << endl;
	cout << endl;
	cout << "Enter the book ID!\t:";
	cin >> bid;
	cout << endl;
	cout << "Enter the no. of pages of book!\t:";
	cin >> nop;
	cout << endl;
	cout << "Enter the book name!\t:";
	cin >> bn;
	cout << endl;
	cout << "Enter the book's auther name!\t:";
	cin >> an;
	cout << endl;
	cout << "Enter the book's issuer name!\t:";
	cin >> in;
	cout << endl;
	ofstream output;
	output.open("book.txt", ios::app);
	if (!output)
	{
		cout << "File cannot be opened!!!" << endl;
	}
	else
	{
		output << "\n" << bid << "\t\t" << nop << "\t\t " << bn << "\t\t" << an << "\t\t " << in << "\n";
		cout << endl;
		output.close();
		cout << "\nYou have successfully created a book in the library!" << endl;
	}
}
void book::modify()
{
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << "\t\t\t| LIBARARY MANEGMENT SYSTEM |" << endl;
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << endl;
	string cid, bid, nop, bn, an, in;
	int n1 = 0, n2 = 0;
	cout << "Enter  book Id(which u wnt to modify)\t:";
	cin >> cid;
	cout << endl;
	ifstream input("book.txt");
	ofstream output("temp.txt");
	if (!input)
	{
		cout << "Input file failed to open(not exist)\n";
	}
	else
	{
		while (input >> bid >> nop >> bn >> an >> in)
		{
			n1++;
			if (cid == bid)
			{
				string bid, nop, bn, an, in;
				cout << "Enter the attributes of book which you wnt to modify in existing book recrd!" << endl;
				cout << "\nEnter the book ID!\t:";
				cin >> bid;
				cout << endl;
				cout << "Enter the no. of pages of book!\t:";
				cin >> nop;
				cout << endl;
				cout << "Enter the book name!\t:";
				cin >> bn;
				cout << endl;
				cout << "Enter the book's auther name!\t:";
				cin >> an;
				cout << endl;
				cout << "Enter the book's issuer name!\t:";
				cin >> in;
				cout << endl;
				output << "\n" << bid << "\t\t" << nop << "\t\t " << bn << "\t\t" << an << "\t\t " << in;
				cout << endl;
				cout << "You have successfully modified a book in the library!" << endl;
				cout << endl;
			}
			else
			{
				n2++;
				output << "\n" << bid << "\t\t" << nop << "\t\t " << bn << "\t\t" << an << "\t\t " << in << '\n';
			}
		}
		if (n1 == n2)
		{
			cout << "\nThe entered BId not exist so can't be modified" << endl;
			cout << endl;
		}
		input.close();
		output.close();
		remove("book.txt");
		rename("temp.txt", "book.txt");
	}
}
void book::search()
{
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << "\t\t\t| LIBARARY MANEGMENT SYSTEM |" << endl;
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << endl;

	string bid, nop, bn, an, in;
	int n1 = 0, n2 = 0;
	string c;
	ifstream input;
	cout << "Enter the book id of book which you want to search in the library:" << endl;
	cout << endl;
	cout << "Enter the Book ID\t:";
	cin >> c;
	cout << endl;
	input.open("book.txt", ios::in);
	if (!input)
	{
		cout << "File cannot be opened!!!" << endl;
	}
	else
	{
		while (input >> bid >> nop >> bn >> an >> in)
		{
			n1++;
			if (bid == c)
			{
				cout << "The record is as follows!!" << endl << endl;
				cout << "No. of pages\tBook name\tAuther name\tIssuer name\n\n";
				cout << "\n" << nop << "\t\t" << bn << "\t\t" << an << "\t\t" << in << '\n';
			}
			else {
				n2++;
			}
		}
		if (n1 == n2)
		{
			cout << "\nThe entered Book ID not exist so can't be searched" << endl;
			cout << endl;
		}
		cout << endl;
	}
}
void book::Delete()
{
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << "\t\t\t| LIBARARY MANEGMENT SYSTEM |" << endl;
	cout << "\t\t\t*****************************\t\t\t" << endl;
	cout << endl;
	int i = 0, n1 = 0, n2 = 0;
	char bid[30], nop[30], bn[30], an[30], in[30];
	string eid;
	cout << "Enter book ID for delete\t :";
	cin >> bid;
	cout << endl;
	for (i = 0; bid[i] != '\0'; i++);
	ifstream input;
	ofstream output;
	input.open("book.txt");
	if (!input)
	{
		cout << "Input file not exist ";
	}
	else
	{
		output.open("temp.txt");
		while (input >> eid >> nop >> bn >> an >> in)
		{
			n1++;
			if (bid == eid)
			{
				cout << "\nThe entered Book ID recrd has been Dleted....!" << endl;

			}
			else
			{
				n2++;
				output << "\n" << eid << "\t\t" << nop << "\t\t" << bn << "\t\t" << an << "\t\t" << in << "\n" << endl;
			}
		}
		if (n1 == n2)
		{
			cout << "Cannot delet this record as the ID is not found!" << endl;
		}


		input.close();
		output.close();
		remove("book.txt");
		rename("temp.txt", "book.txt");

	}
}
void book::showissueandreturn()
{
	int ch1;
	do
	{
		system("cls");
		cout << "\n\n\t\t******* Issue and Return Menu *******";
		cout << endl;
		cout << "\n\n\t1.Issue a book to a student ";
		cout << "\n\n\t2.Return book to librarian";
		cout << "\n\n\t3.Check limit to issue a book ";
		cout << "\n\n\t0.Exit....";
		cout << "\n\n\nEnter your choice what do you want to do::" << endl;
		cin >> ch1;
		switch (ch1)
		{
		case 1:
			obj.issue();
			break;
		case 2:
			o.ret_book();
			break;
		case 3:
			obj.lim_check();
			break;
		case 0:
			exit;
			break;
		default:
			cout << "\n\nSorry...Entered wrong choice....";
		}
		cout << endl;
		system("Pause");
		system("cls");
	} while (ch1 != 0);
}
void book::print()
{
	int ch1;
	do
	{
		system("cls");
		cout << "\n\n\t\t\t******* B O O K <-----> M E N U *******";
		cout << "\n\n\t1.create A Book In Library";
		cout << "\n\n\t2.modify A Book Details";
		cout << "\n\n\t3.search A Book from Library";
		cout << "\n\n\t4.Delete A Book In Library";
		cout << "\n\n\t0.Exit....";
		cout << "\n\n\nEnter your choice what do you want to do::" << endl;
		cin >> ch1;
		switch (ch1)
		{
		case 1:
			create();
			break;

		case 2:
			modify();
			break;
		case 3:
			search();
			break;
		case 4:
			Delete();
			break;
		case 0:
			cout << "\n\n\t\t Exiting Library Management System.....";
			break;
		default: cout << "\n\nSorry...Entered wrong choice....";
		}
		cout << endl;
		system("Pause");
		system("cls");
	} while (ch1 != 0);
}
