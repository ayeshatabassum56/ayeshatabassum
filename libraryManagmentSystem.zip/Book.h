#pragma once
#include<iostream>
#include<fstream>
#include <conio.h>
#include "IssueBook.h"
#include"ReturnBook.h"
using namespace std;
class book
{
private:
	string bid;           //Book ID.
	string nop;          //No. of pages.
	string bn;          //Book name.
	string an;         //Auther name.
	string in;        //Issuer name.
	ifstream input;
	ofstream output;
	Issuebook obj;
	return_book o;
public:
	void create();
	void modify();
	void search();
	void Delete();
	void print();
	void showissueandreturn();
};