#pragma once
#include<iostream>
#include<fstream>
using namespace std;
class return_book
{
private:
	string rbid;
	string rsid;
	int Idcheck, rcheck;
	string bid, n, nop, an, in, stdid;
	int np = 0, t = 0, Uid, Urno;
	int ID, Rno, noib;
	string Bkname, Stdname, Aname, Iname, Dep, semster;
	int n1 = 0, n2 = 0;
public:
	void ret_book();
};

