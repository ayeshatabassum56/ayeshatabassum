﻿#include "LibraryManagementSystem.h"
using namespace std;
int main()
{
	LibraryManagementSystem ob;
	ob.login();
	cout << endl << endl << endl;
	cout << "\t\t\t\t\t";
	system("pause");
	ob.firstmenu();
	system("pause");
	return 0;
}








